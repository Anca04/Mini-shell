#include <stdio.h>
int main() { int i; scanf("%d", &i); fprintf(stdout, "%d", 2 * i); fprintf(stderr, "%d", 4 * i); return 0; }
